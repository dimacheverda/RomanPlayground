//: Playground - noun: a place where people can play

import UIKit

let arabicNumber = 1245

func transformToRoman(arabic: Int) -> String? {
  guard arabic > 0 && arabic < 4000 else {
    return ""
  }
  
  var roman = ""
  
  let romans = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
  let arabics = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
  
  var input = arabic
  
  for (index, element) in arabics.enumerate() {
    while input >= element {
      roman += romans[index]
      input -= arabics[index]
    }
  }
  
  return roman
}

transformToRoman(arabicNumber)
